

public class MainClass {

	public static void main(String[] args) {
		PhaseOneProject o=new PhaseOneProject();
		o.program();

	}

}