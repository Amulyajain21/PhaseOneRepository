

import java.io.File;

public class DisplayFiles {
	public void display()
	{
		File file=new File("C:\\Users\\amujain\\Desktop\\Amulya Jain doc\\PhaseOne");
		String[] f=file.list();
		for(String str :f)
			System.out.println(str);
	}


}
